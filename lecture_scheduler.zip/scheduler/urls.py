from django.urls import path
from . import views


urlpatterns=[
	path('', views.home, name='home'),
	path('Admin_login/', views.Admin_login, name='Admin_login'),
	path('Instructor_login/', views.Instructor_login, name='Instructor_login'),
	path('logout/', views.logout, name='logout'),
	path('AddCourse/', views.AddCourse, name='AddCourse'),
	path('ViewCourses/', views.ViewCourses, name='ViewCourses'),
	path('ViewInstructors/', views.ViewInstructors, name='ViewInstructors'),
	path('ViewLectures/<username>', views.ViewLectures, name='ViewLectures'),
	path('Assigned/', views.Assigned, name='Assigned'),
	path('Assignlec/', views.Assignlec, name='Assignlec'),

]