from django import forms

class ImagefieldForm(forms.Form):
   image_field = forms.ImageField()