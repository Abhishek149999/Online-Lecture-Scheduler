from django.shortcuts import render,redirect
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.contrib import messages
from .models import Admin_Details,Instructor_Details,Courses,Lecture
from django import forms

import random
from django.contrib.sessions.models import Session
from datetime import date
from datetime import datetime
from datetime import timedelta
from django.http import HttpResponse
# Create your views here.



def home(request):
    if request.method == 'POST':
        pass
    else:
        return render(request, 'home.html', {})


def logout(request):
    Session.objects.all().delete()
    messages.info(request,'Account logout')
    return redirect('/')


def Admin_login(request):
    if request.method == 'POST':
        Username = request.POST['Username']
        password = request.POST['password']
        
        if Admin_Details.objects.filter(Username=Username, Password=password).exists():
                user = Admin_Details.objects.get(Username=Username, Password=password)
                request.session['type_id'] = 'Admin'
                request.session['username'] = Username
                request.session['login'] = 'Yes'
                return redirect('/')
        else:
            messages.info(request,'Invalid Credentials')
            return redirect('/Admin_login/')
    else:
        return render(request, 'Admin_login.html', {})


def Instructor_login(request):
    if request.method == 'POST':
        Username = request.POST['Username']
        password = request.POST['password']
        
        if Instructor_Details.objects.filter(Username=Username, Password=password).exists():
                user = Instructor_Details.objects.get(Username=Username, Password=password)
                request.session['type_id'] = 'Instructor'
                request.session['username'] = Username
                request.session['login'] = 'Yes'
                return redirect('/')
        else:
            messages.info(request,'Invalid Credentials')
            return redirect('/Instructor_login/')
    else:
        return render(request, 'Instructor_login.html', {})

class ImagefieldForm(forms.Form):
   image_field = forms.ImageField()


def AddCourse(request):


    if request.method == 'POST':


        Name = request.POST['Name']
        Level = request.POST['Level']
        Description = request.POST['Description']
        Batches = request.POST['Batches']
        Image = request.POST['img']
        addcourse = Courses( Name=Name, Level=Level, Description=Description, 
            Image=Image, Batches=Batches , )
        addcourse.save()
        messages.info(request,'Course Added Successfully')
        return redirect('/AddCourse/')
        
        pass
    else:
        return render(request, 'AddCourse.html', {})  


def ViewCourses(request):
    if request.method == 'POST':
        pass
    else:
        course = Courses.objects.all()
        return render(request, 'ViewCourses.html', {'Courses':course})

              
def ViewInstructors(request):
    if request.method == 'POST':
        pass
    else:
        Instructors = Instructor_Details.objects.all()
        return render(request, 'ViewInstructors.html', {'Instructors':Instructors})



              
def ViewLectures(request,username):
    
    Lectures = Lecture.objects.all().filter(Username=username)
    return render(request, 'ViewLectures.html', {'Lectures':Lectures})

              
def Assigned(request):
    if request.method == 'POST':
        pass
    else:
        Lectures = Lecture.objects.all()
        return render(request, 'Assigned.html', {'lecture':Lectures})




def Assignlec(request):

    if request.method == 'POST':
        Name = request.POST['Name']
        Batch = request.POST['Batch']
        Date = request.POST['Date']
        Username = request.POST['Username']
        i=Lecture.objects.all().filter(Date=Date,Username=Username).count()
        if(i>0):
            messages.info(request,'Instructor has Lecture on this Date, Please Allocate the Lecture to another Faculty')
            return redirect('/Assigned/')


        else:
  


            addlecture = Lecture( Name=Name, Batch=Batch, Date=Date, 
            Username=Username, )
            addlecture.save()
            messages.info(request,'Lecture Assigned Successfully')   
            return redirect('/Assigned/')

    else:
        return redirect('/Assigned/')            