from django.db import models

# Create your models here.

class Admin_Details(models.Model):
    Username = models.CharField(max_length=100)
    Password = models.CharField(max_length=100)
    
    class Meta:
        db_table = 'Admin_Details'




class Instructor_Details(models.Model):
    Username = models.CharField(max_length=100)
    Password = models.CharField(max_length=100)
    Name = models.CharField(max_length=20,default=None)
    Subjects = models.CharField(max_length=50,default=None)
    Location = models.CharField(max_length=20,default=None)
    Gender = models.CharField(max_length=10,default=None)

    
    class Meta:
        db_table = 'Instructor_Details' 
               
class Courses(models.Model):
    Name = models.CharField(max_length=50,default=None)
    Level = models.CharField(max_length=20,default=None)
    Description = models.CharField(max_length=200,default=None)
    Batches = models.CharField(max_length=10,default=None)
    Image = models.CharField(max_length=1000,default=None)



    
    class Meta:
        db_table = 'Courses' 
               
class Lecture(models.Model):
    Name = models.CharField(max_length=20,default=None)
    Batch = models.IntegerField()
    Username = models.CharField(max_length=20,default=None)
    Date = models.DateField()



    
    class Meta:
        db_table = 'Lecture' 
               